from ast import While
import string
from numpy import append
import serial
import time
import matplotlib.pyplot as plt
from drawnow import *
Hum=[]
Temp=[]
Pot=[]
plt.ion()
cnt=0

def makeFig():
    plt.ylim(40,99)
    plt.title('Read Live Data Sensor & Potensio')
    plt.grid(True)
    plt.ylabel('Hum %')
    plt.plot(Hum, 'ro-', label='Persen %')
    plt.legend(loc='upper left')
    plt2=plt.twinx()
    #plt.ylim(93500,93525)
    plt2.plot(Temp, 'b^-', label='Temperature °C')
    plt2.set_ylabel('Temperature C')
    plt2.ticklabel_format(useOffset=False)
    plt2.legend(loc='upper right')
    plt3=plt.twinx()
    plt3.plot(Pot, 'g-', label='Potensio ADC')
    plt3.set_ylabel('Potensio ADC')
    plt3.ticklabel_format(useOffset=False)
    plt3.legend(loc='upper center')

# make sure the 'COM#' is set according the Windows Device Manager
ser = serial.Serial('COM6', 115200, timeout=1)
time.sleep(2)



while True:
    b = ser.readline()         # read a byte string
    if len(b) != 0:
        string1 = b.decode()
        string = string1.rstrip() # remove \n and \r

        index=string.split(',')
        H=float(index[0])
        T=float(index[1])
        P=float(index[2])

        Hum.append(H)
        Temp.append(T)
        Pot.append(P)
        drawnow(makeFig)
        plt.pause(0.000001)
        cnt=cnt+1
        if(cnt>50):
            Hum.pop(0)
            Temp.pop(0)
            Pot.pop(0)
