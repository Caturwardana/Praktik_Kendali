from ast import While
import string
from numpy import append
import serial
import time
import matplotlib.pyplot as plt
from drawnow import *
Hum=[]
Temp=[]
Pot=[]
Temp35=[]
plt.ion()
cnt=0

f = plt.figure()
f.set_figwidth(10)
f.set_figheight(7)

def makeFig():
   
    plt.subplot(2, 2, 1)
    plt.ylim(40,99)
    plt.title('Read Live Data Sensor DHT HUMUDITY')
    plt.grid(True)
    plt.ylabel('Hum %')
    plt.plot(Hum, 'ro-', label='Persen %')
    plt.legend(loc='upper left')

    plt.subplot(2, 2, 2)
    #plt=plt.twinx()
    plt.title('Read Live Data Sensor DHT TEMPERATURE')
    plt.plot(Temp, 'b^-', label='Temp °C')
    plt.ylabel('Temp C')
    plt.ticklabel_format(useOffset=False)
    plt.legend(loc='upper left')

    plt.subplot(2, 2, 3)
    #plt3=plt.twinx()
    plt.title('Read Live Data ADC POTENSIO')
    plt.plot(Pot, 'g-', label='Potensio ADC')
    plt.ylabel('Potensio ADC')
    plt.ticklabel_format(useOffset=False)
    plt.legend(loc='upper left')

    plt.subplot(2, 2, 4)
    #plt4=plt.twinx()
    plt.title('Read Live Data Sensor LM35 TEMPERATURE')
    plt.plot(Temp35, 'y^-', label='Temp LM °C')
    plt.ylabel('Temp LM C')
    plt.ticklabel_format(useOffset=False)
    plt.legend(loc='upper left')

# make sure the 'COM#' cocok dengan serial yang didgunakan pada esp
ser = serial.Serial('COM6', 115200, timeout=1)
time.sleep(2)



while True:
    b = ser.readline()         # read a byte string
    if len(b) != 0:
        string1 = b.decode()
        string = string1.rstrip() # remove \n and \r

        index=string.split(',')
        P=float(index[0])
        H=float(index[1])
        T=float(index[2])
        T35=float(index[3])

        Pot.append(P)
        Hum.append(H)
        Temp.append(T)
        Temp35.append(T35)
        
        drawnow(makeFig)
        plt.pause(0.000001)
        cnt=cnt+1
        if(cnt>50):
            Pot.pop(0)
            Hum.pop(0)
            Temp.pop(0)
            Temp35.pop(0)