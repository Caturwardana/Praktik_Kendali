import tkinter
import requests

main_window = tkinter.Tk()
payload = ""

label2 = tkinter.Label(main_window, text="")


def event_Relay1():
    global label2
    label2.pack_forget()
    label2 = tkinter.Label(main_window, text="Relay1 Hidup ^_^")
    label2.pack()
    payload = "on"
    requests.get(("http://192.168.43.124/Relay1/" + payload))


def event_Relay2():
    global label2
    label2.pack_forget()
    label2 = tkinter.Label(main_window, text="Relay2 Hidup ^_^")
    label2.pack()
    payload = "on"
    requests.get(("http://192.168.43.124/Relay2/" + payload))


def event_Relay3():
    global label2
    global label2
    label2.pack_forget()
    label2 = tkinter.Label(main_window, text="Relay3 Hidup ^_^")  
    label2.pack()
    payload = "on"
    requests.get(("http://192.168.43.124/Relay3/" + payload))


def event_Relay4():
    global label2
    label2.pack_forget()
    label2 = tkinter.Label(main_window, text="Relay4 Hidup ^_^")
    label2.pack()
    payload = "on"
    requests.get(("http://192.168.43.124/Relay4/" + payload))


def event_off():
    global label2
    label2.pack_forget()
    label2 = tkinter.Label(main_window, text="Semua Relay Mati ^_^")
    label2.pack()
    payload = "off"
    requests.get(("http://192.168.43.124/RelayOff/" + payload))


label = tkinter.Label(
    main_window, text="halo, ini adalah \n GUI sederhana untuk mngontrol ESP32 \n menggunakan python GUI")
tombol1 = tkinter.Button(main_window, text="RELAY 1: ON", command=event_Relay1)
tombol2 = tkinter.Button(main_window, text="RELAY 2: ON", command=event_Relay2)
tombol3 = tkinter.Button(main_window, text="RELAY 3: ON", command=event_Relay3)
tombol4 = tkinter.Button(main_window, text="RELAY 4: ON", command=event_Relay4)
tombol_off = tkinter.Button(
    main_window, text="Semua RELAY OFF", command=event_off)


label.pack()
tombol1.pack()
tombol2.pack()
tombol3.pack()
tombol4.pack()
tombol_off.pack()
main_window.mainloop()
