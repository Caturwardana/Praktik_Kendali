from pyHS100 import SmartPlug
from pprint import pformat as cx
from tkinter import *
window_main = Tk(className='Smart Plug',)
window_main.geometry("400x200")

plug = SmartPlug("192.168.0.1")
print("Hardware: %s" % cx(plug.hw_info))
print("Full sysinfo: %s" % cx(plug.get_sysinfo()))

print("Current state: %s" % plug.state)

plug.turn_on
plug.turn_off

plug.state = "ON"
print("Current state: %s" % plug.state)

print("Current LED state: %s" % plug.led)
plug.led = True 
print("New LED state: %s" % plug.led)

def plugFunctionON() :
    plug.state = "ON"
def plugFunctionOFF() :
    plug.state = "OFF"
def close():
    window_main.destroy()

myButton1 = Button(window_main, text="Plug ON", command=plugFunctionON)
myButton1.config(width=20, height=2)
myButton2 = Button(window_main, text="Plug OFF",command=plugFunctionOFF)
myButton2.config(width=20, height=2)
myButton3 = Button(window_main, text="Exit",command=close)
myButton3.config(width=20, height=2)
myButton1.pack()
myButton2.pack()
myButton3.pack()

window_main.mainloop()



