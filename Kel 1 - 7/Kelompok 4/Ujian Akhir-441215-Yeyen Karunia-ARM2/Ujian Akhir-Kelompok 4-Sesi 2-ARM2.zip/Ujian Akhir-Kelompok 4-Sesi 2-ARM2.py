import serial
from tkinter import *
import tkinter as tk
from paho.mqtt import client as mqtt_client

commPort = 'COM3'
ser = serial.Serial(commPort, baudrate = 115200, timeout = 1)

# MQTT
broker = '10.33.162.50'
port = 1883
topic4 = "esp32/4"
topic5 = "esp32/5"
topic_sub = "esp32/status"
# generate client ID with pub prefix randomly
client_id = 'your client id'
username = 'UGM-Hotspot'
password = ''
deviceId = "your deviceId"

def connect_mqtt():
    def on_connect(client, userdata, flags, rc):
        if rc==0:
            print("Successfully connected to MQTT broker")
        else:
            print("Failed to connect, return code %d", rc)
 
    client = mqtt_client.Client(client_id)
    client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client
 
def publish4(client, status):
    result = client.publish(status,topic4)
    msg_status = result[0]
    if msg_status ==0:
        print(f"message : {status} sent to topic {topic4}")
    else:
        print(f"Failed to send message to topic {topic4}")

def publish5(client, status):
    result = client.publish(status,topic5)
    msg_status = result[0]
    if msg_status ==0:
        print(f"message : {status} sent to topic {topic5}")
    else:
        print(f"Failed to send message to topic {topic5}")
 

# MQTT End

def turnOnLED():
    ser.write(b'1')

def turnOnLED1():
    ser.write(b'2')

def turnOnLEDall():
    ser.write(b'5')


def turnOffLED(): 
    ser.write(b'a')

def turnOffLED1(): 
    ser.write(b'b')

def turnOffLEDall(): 
    ser.write(b'e')

def exitGUI():
    root.destroy()

# GUI

root = Tk()
root.title("Ujian Teknik Kendali-Kelompok 4-Sesi 2- MQTT ESP32")
root.geometry("500x800")

btn_On= tk.Button(root, text="Turn On LED 1", bg="lightgreen", width = 15, height = 4, bd=3, command=turnOnLED)
btn_On.grid(row=0, column=0)

btn_On1= tk.Button(root, text="Turn On LED 2", bg="lightgreen", width = 15, height =4, bd=3, command=turnOnLED1)
btn_On1.grid(row=1, column=0)

btn_On4= tk.Button(root, text="Turn On LED all", bg="lightgreen", width = 15, height =4, bd=3, command=turnOnLEDall)
btn_On4.grid(row=4, column=0)

btn_Off = tk.Button(root, text="Turn Off LED 1", bg="red", width = 15, height =4, bd=3, command=turnOffLED)
btn_Off.grid(row=0, column=1)

btn_Off1 = tk.Button(root, text="Turn Off LED 2", bg="red", width = 15, height =4, bd=3, command=turnOffLED1)
btn_Off1.grid(row=1, column=1)

btn_Off4 = tk.Button(root, text="Turn Off LED all", bg="red", width = 15, height =4, bd=3, command=turnOffLEDall)
btn_Off4.grid(row=4, column=1)

btn_Off5 = tk.Button(root, text="EXIT", bg="lightblue", width = 15, height =4, bd=3, command=exitGUI)
btn_Off5.grid(row=7, column=1)

root.mainloop()

# GUI END

# Start Program
client = connect_mqtt()
# subscribe(client)
client.loop_start()
 
root.mainloop()
client.loop_stop()